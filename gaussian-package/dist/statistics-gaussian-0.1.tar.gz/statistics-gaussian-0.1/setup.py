from setuptools import setup

setup(name='statistics-gaussian',
      version='0.1',
      describtion=' Gaussian Distribution ',
      packages=['statistics-gaussian'],
      author = 'mahmoud samir badr',
      author_mail = 'mahmoudsamirmohammed999@yahoo.com',
      zip_safe=False)
